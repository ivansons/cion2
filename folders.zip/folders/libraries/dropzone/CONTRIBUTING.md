Contribute
==========

DO NOT CREATE PULL REQUESTS ON GITHUB!

I will simply close them. If you want to contribute, please use [gitlab.com](https://gitlab.com/meno/dropzone) instead.